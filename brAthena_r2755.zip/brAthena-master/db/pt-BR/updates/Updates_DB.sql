/*_________________________________________________________________________
 /                                                                         \
 |                  _           _   _   _                                  |
 |                 | |__  _ __ / \ | |_| |__   ___ _ __   __ _             |
 |                 | '_ \| '__/ _ \| __| '_ \ / _ \ '_ \ / _` |            |
 |                 | |_) | | / ___ \ |_| | | |  __/ | | | (_| |            |
 |                 |_.__/|_|/_/   \_\__|_| |_|\___|_| |_|\__,_|            |
 |                                                                         |
 |                       brAthena © 2013 - Banco de Dados                  |
 |        Contém as tabelas de updates para habilidades, itens e monstros  |
 \_________________________________________________________________________/
*/

-- 018/11/2013

REPLACE INTO `const_db` VALUES('MER_LIF','6001',0);
REPLACE INTO `const_db` VALUES('MER_AMISTR','6002',0);
REPLACE INTO `const_db` VALUES('MER_FILIR','6003',0);
REPLACE INTO `const_db` VALUES('MER_VANILMIRTH','6004',0);
REPLACE INTO `const_db` VALUES('MER_LIF2','6005',0);
REPLACE INTO `const_db` VALUES('MER_AMISTR2','6006',0);
REPLACE INTO `const_db` VALUES('MER_FILIR2','6007',0);
REPLACE INTO `const_db` VALUES('MER_VANILMIRTH2','6008',0);
REPLACE INTO `const_db` VALUES('MER_LIF_H','6009',0);
REPLACE INTO `const_db` VALUES('MER_AMISTR_H','6010',0);
REPLACE INTO `const_db` VALUES('MER_FILIR_H','6011',0);
REPLACE INTO `const_db` VALUES('MER_VANILMIRTH_H','6012',0);
REPLACE INTO `const_db` VALUES('MER_LIF_H2','6013',0);
REPLACE INTO `const_db` VALUES('MER_AMISTR_H2','6014',0);
REPLACE INTO `const_db` VALUES('MER_FILIR_H2','6015',0);
REPLACE INTO `const_db` VALUES('MER_VANILMIRTH_H2','6016',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER01','6017',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER02','6018',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER03','6019',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER04','6020',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER05','6021',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER06','6022',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER07','6023',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER08','6024',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER09','6025',0);
REPLACE INTO `const_db` VALUES('MER_ARCHER10','6026',0);
REPLACE INTO `const_db` VALUES('MER_LANCER01','6027',0);
REPLACE INTO `const_db` VALUES('MER_LANCER02','6028',0);
REPLACE INTO `const_db` VALUES('MER_LANCER03','6029',0);
REPLACE INTO `const_db` VALUES('MER_LANCER04','6030',0);
REPLACE INTO `const_db` VALUES('MER_LANCER05','6031',0);
REPLACE INTO `const_db` VALUES('MER_LANCER06','6032',0);
REPLACE INTO `const_db` VALUES('MER_LANCER07','6033',0);
REPLACE INTO `const_db` VALUES('MER_LANCER08','6034',0);
REPLACE INTO `const_db` VALUES('MER_LANCER09','6035',0);
REPLACE INTO `const_db` VALUES('MER_LANCER10','6036',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN01','6037',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN02','6038',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN03','6039',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN04','6040',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN05','6041',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN06','6042',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN07','6043',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN08','6044',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN09','6045',0);
REPLACE INTO `const_db` VALUES('MER_SWORDMAN10','6046',0);